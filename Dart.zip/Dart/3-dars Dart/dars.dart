import 'dart:io';
import 'dart:math';
void main(){

  // int oy = 1;

  // switch(oy){
  //   case 1: print("Yanvar");
  //   case 2: print("Fevral");
  //   case 3: print("Mart");
  //   case 4: print("Aprel");
  //   case 5: print("Mayr");
  //   case 6: print("Iyun");
  //   case 7: print("Iyul");
  //   case 8: print("Avgust");

  // }

  // int  a = 12;

  // if(a % 2 == 0){
  //   print("Juft");
  // }
  // else{
  //   print("Toq");
  // }

  // (a%2 == 0) ? print("Juft"): print("Toq");

  // int age = 22;

  // (age >= 0 && age <= 12) 
  // ? print("Kichik") : (age > 12 && age <= 19) 
  // ? print("O'rta") : (age> 19 )
  // ? print("Katta") : ("No'to'g'ri yosh kiritildi");

  // int a = 5;
  // int b =1;
  // for(var i = 1; i <= a; i ++){
  //   b *= i;
  // }
  // print(b);

  // var sozlar = ["alice", "bob", "charlie"];
  // var a = "ds";
  // if (sozlar[0][0] + sozlar[1][0] + sozlar[2][0] == a) {
  //   print("True");
  // }
  // else{
  //   print("False");
  // }

  // String ? num1 = stdin.readLineSync();
  // String ? num2 = stdin.readLineSync();
  // String ? num3 = stdin.readLineSync();

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.

  // int ? num1 = int.parse(stdin.readLineSync()!);
  // int ? num2 = int.parse(stdin.readLineSync()!);
  // int ? num3 = int.parse(stdin.readLineSync()!);

  // if(num1 == num2 && num2 ==  num3){
  //   print("Barcha sonlar teng");
  // }
  // else if(num1 == num2 || num2 == num3 || num1 == num3){
  //   print("Faqat 2 ta si teng");
  // }
  // else{
  //   print("hammasi xar xil");
  // }

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  // int ? num1 = int.parse(stdin.readLineSync()!);
  // int ? num2 = int.parse(stdin.readLineSync()!);
  // String ? char = stdin.readLineSync();

  // switch(char){
  //   case "+": print(num1 + num2);
  //   case "-": print(num1 - num2);
  //   case "/": 
  //   if (num1 > 0){
  //     print(num1 / num2);
  //   }
  //   else{
  //     print("Nolga bo'lish mumkin emas");
  //   }
  //   case "*": print(num1 * num2);
  //   default: print("Boshqa amal kiritdingiz\n Iltimos ( +, -, *, / lardan birini kiriting!)");
  // }

  // int ? age = int.parse(stdin.readLineSync()!);
  // int ? tajriba = int.parse(stdin.readLineSync()!);

  // if (age > 17 && tajriba >= 2){
  //   print("Ishga qabul qilnishingiz mumkin");
  // }
  // else{
  //   print("Keyingi yil harakat qilib ko'ring");
  // }

  // String name = "admin";
  // int pass = 1234;

  // print("Enter Username");
  // String ? username = stdin.readLineSync();

  // print("Enter password");
  // int ? parol = int.parse(stdin.readLineSync()!);

  // if (name == username && pass == parol){
  //   print("Salom Admin");
  // }
  // else{
  //   print("Siz ro'yxatdan o'tmagansiz\n Login yoki  parol xato!!!");
  // }


// 5


  // int ? num1 = int.parse(stdin.readLineSync()!);
  // if (num1>0){
  //   print("${num1} sonining kvadrat ildizi  ${sqrt(num1)}");
  // }
  // else{
  //   print("Kvadrat ildizi mavjud emas");
  // }

  // 7

  // int ? num1 = int.parse(stdin.readLineSync()!);
  // num1 > 100 ? print("Kiritilgan son 100 dan katta"): print("Kiritilgan son 100 ga teng yoki kichik");

  // 8

  // print("1) Olma\n2) Behi\n3) Gilos");
  // int? num1 = int.parse(stdin.readLineSync()!);
  // switch(num1){
  //   case 1: print("Olmaning narxi 5000 so'm");
  //   case 2: print("Behining narxi 15000 so'm");
  //   case 3: print("Gilosning narxi 35000 so'm");
  //   default: print("Boshqa son kiritdingiz");
  // }

  // 9

  // int ? num1 = int.parse(stdin.readLineSync()!);
  // if(num1 > 0){
  //   if(num1 % 2 == 0){
  //     print("Musbat va juft son");
  //   }
  //   else{
  //     print("Musbat va toq son");
  //   }
  // }
  // else{
  //   if(num1 % 2 == 0){
  //     print("Manfiy va juft son");
  //   }
  //   else{
  //     print("Manfiy va toq son");
  //   }
  // }



 
  String? s = stdin.readLineSync();

  if (s != null) {
    Set<String> prefixes = {};

    for (int i = 0; i < s.length; i++) {
      prefixes.add(s.substring(0, i + 1));
    }

    print(prefixes.length);
  }


}