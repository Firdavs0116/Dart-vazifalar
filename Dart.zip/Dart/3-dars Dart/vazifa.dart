import 'dart:io';
import 'dart:math';

void main(){

  // 1-misol
  
  print("aylana radiusini kiriting!\n");
  int ? radius = int.parse(stdin.readLineSync()!);  
  if(radius > 10){
    print("aylana uzunligi ${2 * 3.14 * radius} ga teng");
  }
  else{
    print("aylana yuzi ${radius * radius * 3.14} ga teng ");
  }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  //2-misol

  // String sonlar = "23651";
  // List<int> raqamlar = sonlar.split('').map(int.parse).toList();
  // raqamlar.sort();
  
  // print("Tartiblangan raqamlar ${raqamlar}");


//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


  // 3-misol

  // print("Nechta talabani baholamoqchisz.");
  // int? talaba = int.parse(stdin.readLineSync()!);
  // print("Talabalarni olgan ballarini kiriting.");
  // var ls = [];
  // for( var i = 0; i < talaba; i++){
  //   int ? ball = int.parse(stdin.readLineSync()!);
  //   ls.add(ball);
  // }
  // ls.sort();
  
  // print("Eng yuqori ball ${ls.last}");

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


  // 4-misol

  // print("2 ta nuqtaning kordinatalarini kiriting : ");
  // print("X1 : ");
  // int ? x1 = int.parse(stdin.readLineSync()!);

  // print("Y1 : ");
  // int ? y1 = int.parse(stdin.readLineSync()!);

  // print("X2 : ");
  // int ? x2 = int.parse(stdin.readLineSync()!);

  // print("Y2 : ");
  // int ? y2 = int.parse(stdin.readLineSync()!);

  // double masofa = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));

  // print("Nuqtalar orasidagi masofa $masofa");


  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


  // 5-misol

  // print("Ha yoki Yo'q ");
  // String ? soz = stdin.readLineSync();
  // if(soz == "Ha" || soz == "ha" ){
  //   print("Siz rozi bo'ldingiz");
  // }
  // else if( soz == "Yo'q" || soz == "yo'q" ){
  //   print("Siz rozi bo'lmadingiz");
  // }
  // else{
  //   print("Boshqa so'z kiritdingiz chog'i!!!");
  // }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


  // 6-misol
  
  // print("2  ta satrda matn kiriting.");
  // String ? satr1 = stdin.readLineSync();
  // String ? satr2 = stdin.readLineSync();

  // if(satr1 == satr2){
  //   print("Satrlar teng");
  // }
  // else{
  //   print("Satrlar teng emas");
  // }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


  // 7-misol
  
  // print("Olgan bahoyingizni kiriting.");
  // int ? baho = int.parse(stdin.readLineSync()!);

  // if(baho >= 90 && baho <= 100){
  //   print("A");
  // }
  // else if( baho < 90 && baho >= 75){
  //   print("B");
  // }
  // else if( baho < 75 && baho >= 60){
  //   print("C");
  // }
  // else if( baho < 60 && baho >= 45){
  //   print("D");
  // }
  // else if( baho < 45 && baho >= 0){
  //   print("F");
  // }
  // else{
  //   print("Xato ball kiritdingiz");
  // }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  // 8-misol
  
  // print("Son kiriting.");
  // int ? son = int.parse(stdin.readLineSync()!);

  // son % 2 == 0 ? print("Siz kiritgan son juft") : print("Siz kiritgan son Toq");

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  // 9-misol
  
  // print(" 1- Qish\n 2- Bahor\n 3- Yoz\n 4- Kuz");
  // int ? fasl = int.parse(stdin.readLineSync()!); 
  // switch(fasl){
  //   case 1 : print("Qish faslida ( Dekabr, Yanvar, Fevral) Oylari mavjud");
  //   case 2 : print("Bahor faslida ( Mart, Aprel, May ) Oylari mavjud");
  //   case 3 : print("Yoz faslida ( Iyun, Iyul, Avgust ) Oylari mavjud");
  //   case 4 : print("Kuz faslida ( Sentabr, Oktabr, Noyabr ) Oylari mavjud");
  // }


  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  // 10-misol
  
  // print("Son kiriting.");
  // int ? son = int.parse(stdin.readLineSync()!);

  // son % 2 == 0 ? print("Siz kiritgan son juft") : print("Siz kiritgan son Toq");

}