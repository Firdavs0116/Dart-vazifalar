void main(){
  List l = [1,23,4,3];
  List tartiblangan = [];
  tartiblangan.add(l[0]);
  for(int i = 0; i < l.length; i++ ){
    int min = i;
    for (int j = i + 1; j < l.length; j++){
      if( l[min] > l[j]){
        min = j;
      }
    }
    tartiblangan.add(l[min]);
    l.remove(min);
  }
  print(tartiblangan);

  
}