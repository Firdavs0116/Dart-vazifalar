import 'dart:io';

// void main(){

  // 1-misol

//   int ? a = int.parse(stdin.readLineSync()!);
//   print(calculateSquare(a));

// }
// int calculateSquare(int son){
//   son *= son;

//   return son;

// 2-misol

//   int? narx = int.parse(stdin.readLineSync()!);
//   int? foiz = int.parse(stdin.readLineSync()!);

//   print(calculateTotalCost(narx, foiz));
// }
// double calculateTotalCost(int a, int foiz){

//   double xarajat = a + (a * (foiz / 100));

//   return xarajat;
// }


// // 3-misol

// void main(){
//   print("Nechi sonigacha factorial hisoblanishi kerak");
//   int? son = int.parse(stdin.readLineSync()!);

//   print(calculateFactorial(son));
// }
// int calculateFactorial(int a){
//   int sum = 1;
//   for(int i = 1; i <= a; i++){
//     sum *= i;
//   }
//   return sum;
// }

// // 4-misol

// void main(){
//   print("Nechta son kiritmoqchisiz.");
//   int? n = int.parse(stdin.readLineSync()!);

//   List<int> sonlar = [];

//   for(int i = 0; i < n; i++){
//     stdout.write("Son ${i + 1} - sonni kiriting: ");
//     int? son = int.parse(stdin.readLineSync()!);
//     sonlar.add(son);
//   }

//   print("Bu sonlarning o'rtachasi - ${calculateAverage(sonlar, n)}");
// }
// double calculateAverage(a, n){
//   int sum = 0;
//   for(int son in a){
//     sum += son;
//   }
//   double everage = n> 0 ? sum / n : 0;
//   return everage;
// }


// 5-misol

// void main(){
//   print("Vazn va bo'yingizni kiriting.");

//   stdout.write("Sizning vazningiz (kg): ");
//   int? kg = int.parse(stdin.readLineSync()!);

//   stdout.write("Sizning bo'yingiz (m): ");
//   double? m = double.parse(stdin.readLineSync()!);
    
//   print("Sizning BMI - ${calculateBMI(kg, m)}");
// }
// double calculateBMI(a, m){
//   double bmi = a / (m * m);
//   return bmi;
// }


// 6-misol

// void main() {
//   stdout.write("Raqamingizni kiriting: ");
//   String? raqam = stdin.readLineSync();

//   if (raqam != null) {
//     String formattedNumber = formatPhoneNumber(raqam);
//     print(formattedNumber);
//   } else {
//     print("Raqam kiritilmadi.");
//   }
// }

// String formatPhoneNumber(String raqam) {
//   if (raqam.length != 12) {
//     return "Telefon raqami 12 ta raqamdan tashkil topgan bo'lishi kerak.";
//   } else {
//     String boshi = raqam.substring(0, 3); // "998"
//     String areaCode = raqam.substring(3, 5); // "91"
//     String firstPart = raqam.substring(5, 8); // "123"
//     String secondPart = raqam.substring(8, 10); // "45"
//     String thirdPart = raqam.substring(10, 12); // "67"

//     return "+$boshi ($areaCode) $firstPart-$secondPart-$thirdPart";
//   }
// }


// 7-misol

// void main(){
//   stdout.write("Summani kiriting: ");
//   int? summa = int.parse(stdin.readLineSync()!);

//   stdout.write("foizni kiriting: ");
//   int? foiz = int.parse(stdin.readLineSync()!);

//   stdout.write("yilni kiriting: ");
//   int? vaqt = int.parse(stdin.readLineSync()!);

//   if(summa != 0 && vaqt != 0){
//     double jami = calculateCompoundInterest(summa, foiz, vaqt);
//     print("Jami olinadigan summa $jami");
//   }
//   else{
//     print("Xato kiritdingiz");
//   }
// }
// double calculateCompoundInterest(summa, foiz, vaqt){
//   for( int i = 1; i <= vaqt; i++){
//     stdout.write("$i - yili qancha invistitsiya qilasiz? ");
//     int? invist = int.parse(stdin.readLineSync()!);

//     double jami = summa * (1 + foiz / 100) + invist;
//     summa = jami;
//   }

  

//   return summa;
// }



// // 8-misol 

// void main(){
//   stdout.write("Celcius: ");
//   int? selsiy = int.parse(stdin.readLineSync()!);

//   print("Faranheyt: ${convertTemperature(selsiy)}");
// }
// convertTemperature(a){
//   if( a != null){
//     num faranheyt = a * 1.8 + 32;
//     return faranheyt;
//   }
//   else{
//     return "Harorat kiritmadingiz";
//   }
// }

// 9-misol 

// void main(){
//   stdout.write("Nechta son kiritmoqchisiz: ");
//   int? n = int.parse(stdin.readLineSync()!);

//   List<int>sonlar = [];

//   for(int i = 0; i < n; i++){
//     stdout.write("${i+1} - sonni kiriting: ");
//     int? son= int.parse(stdin.readLineSync()!);
//     sonlar.add(son);
//   }

//   print("Max son: ${findMax(sonlar, n)}");
// }
// findMax(sonlar, n){
//   int max = sonlar[0];
//   for( int i = 0; i < n; i++){
//     for( int l = 1; l < n; l++){
//       if( max < sonlar[l]){
//         max = sonlar[l];
//       }
//     }
//   }
//   return max;
// }


// 10-misol

void main(){
  stdout.write("1-sonni kiriting: ");
  int? a = int.parse(stdin.readLineSync()!);

  stdout.write("2-sonni kiriting: ");
  int? b = int.parse(stdin.readLineSync()!);

  print("EKUB: ${greatestCommonDivisor(a, b)}");
}
greatestCommonDivisor(a, b){

  if( a > b){
    if( a % b == 0){
      return b;
    }
    else{
      for( int i = b; i != 0; i--){
        if( a % i == 0 && b % i == 0){
          return i;
        }
      }
    }
  }
  else if( a < b){
    if( b % a == 0){
      return a;
    }
    else{
      for( int i = a; i != 0; i--){
        if( b % i == 0 && a % i == 0){
          return i;
        }
      }
    }
  }
  else if( a == b ){
    return a;
  }

}