void main() {


  //  1-misol

  // var a = 35;
  // var b = 19;
  // var c = a | (b^a);
  // var d = (c & b) << 2;
  // var e = ~d | (c >> 3);

  // print("c = $c");
  // print("d = $d");
  // print("e = $e");

  // 1) a ni ham b ni ham 2 lik ko'rinishiga olib o'tamiz
  //    a =  00100011;
  //    b =  00010011; 
  // 
  // c) Birinchi qavslarni ochamiz (b^a)
  //    00100011
  //    00010011 bunda 1 va 0 kelganida 1 yoziladi natija esa 00110000 chiqadi
  //    00110000 bu esa 10 lik sistemada 48 ga teng
  //    c = a | (b ^ a)  bunda 35 | 48 
  //    00100011
  //    00110000 natija: 00110011 bu 10 lik sistemada c = 51 ga teng
  //
  // d) d = (c & b) << 2
  //    bunda qavsni ochamiz
  //    51 = 00110011
  //    19 = 00010011 natija = 00010011 bu 10 lik sistemada 19 ga teng
  //    ( << 2) amalida chap tarafdan  2 xonani o'chirib o'ng tarafga yozamiz
  //    00010011 = 01001100 ga teng bu esa 76 ga teng
  //    d = 76
  // 
  // e) e = ~d | (c >> 3)
  //    76 = 01001100
  //    ~d = 10110011
  //    agar shunda gi 1 chi raqam 1 bo'lsa bu son manfiy bo'ladi
  //    01001100 ga 1 ni qo'shamiz 01001101 bu esa 77 ga teng 
  //    ~d = -77 ga teng bo'ladi
  //    endi qavsni ochamiz 
  //    c = 51 = 00110011 >> 3 bunda natija 00000110 ga bu esa 6 ga teng
  //    ~d | (c>>3)
  //    10110011
  //    00000110 natija =  10110111 bu esa -73 ga teng//


// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// 2-misol

// int a = 10;
// int b = 20;
// a += 5;
// b *= a;
// a -= 7;
// print(a); // a = 8
// print(b); // b = 300

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// 3-misol
// int m = 18;
// int n = 7;
// m ^= n;
// n = ~n;
// print(m);  // m = 21
// print(n);  // n = -8

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 4-misol
// int age = 25;
// bool hasLicense = true;
// var isEligible = age >= 20 && hasLicense;
// print(isEligible);  // true

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 5-misol

// int temp = 25;
// String weather;
// temp > 30 ? weather = "Issiq":temp > 15 ? weather = "Muvaffaqqiyatli" : weather = "Sovuq";
// print(weather);  // Muvaffaqqiyatli

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 6-misol

//int = Butun va musbat sonlarni qabul qiladi
//int a = 2
//int b = 10
//
//double = O'nlik sonllarni qabul qiladi
//doube a = 10.11
//double b = 12.24
//
//bool = Mantiqiy ya'ni true yoki false qaytaradi
//
//String Matnli ma'lumotlar / Characters qabul qiladi
//String name = "Firdavs"

//List = Barcha turdagi ma'lumotlarni saqlaydi
//List<int> numbers = [1, 2, 3, 4, 5];
//List<String> fruits = ["Olma", "Nok", "Banan"];

// 
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 7-misol

//Dynamic va Obyekt farqi shundaki Dynamic holatda yozganimizda kodni run qilganimizda xatolik qaytaradi ya'ni runtime error
// Obyekt da esa kodni yozayotganimizda xatoni ko'rsatib turadi

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 8-misol

// Truth table
//  [A, B, A && B]     [A, B, A || B ]    [A, !A]
//  [1, 0, 0]          [0, 0, 0]          [1, 0]
//  [1, 1, 1]          [0, 1, 1]          [0, 1]
//  [0, 1, 0]          [1, 1, 1]          
//  [0, 0, 0]          [1, 0, 1]          
//
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 9-misol
// int a = 10;
// int b = 5;
// num c = -3;

// if (a > 10 && b > 5){
//   print("Shart bajarildi");
// }
// else if( c < 0 ){
//   print("Manfiy son");
// }
// else if (a == 20){
//   print("20");
// }


// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// 10-misol
int x = 15;
int y = 10;

if (x > 10 && y > 5){
  print("Ikkala shart ham to'g'ri");
}
else if(x < 20 || y > 15){
  print("Birinchi yoki ikkinchi shart to'g'ri");
}
else if( x > 0 && y > 0){
  print("Ikkalasi ham musbat" );
}
}