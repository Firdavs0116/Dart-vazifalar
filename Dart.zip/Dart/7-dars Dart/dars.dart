

// class Mahsulot{
//   String? mom;
//   int? narx;
//   int? miqdor;

//   Mahsulot(this.mom, this.miqdor);

//   mahsulotMalumotlari(){
//     return "Nomi: $mom\nMiqdori: $miqdor";
//   }
// }

// void main(){
//   Mahsulot phone = Mahsulot("Samsung", 23);
//   print(phone.mahsulotMalumotlari());
// }

class Kompyuter{
  String? markasi;
  String? modeli;
  double? narxi;
  String? operatsinTizimi;
  int? RAM;
  int? xotira;

  Kompyuter();

  Kompyuter.narxiBaland(double? narxi){
    if ( narxi != Null){
      this.narxi;
    }
    this.narxi = 1000;
  }

  toliqMalumot(){
    return "    Komputer\nnomi: $modeli\nMarkasi: $markasi\nNarxi: $narxi\nOperatsion tizimi: $operatsinTizimi\nXotirasi: $xotira\nRAM: $RAM";
  }
  narxYangilovchi(){

  }
  ramYangilovchi(){

  }

}

class KompyuterDokoni{

}

void main(){


}