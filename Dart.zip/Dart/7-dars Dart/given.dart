// class Xodim {
//   String? ism;
//   double? oylikMaosh;
//   int? ishTajribasi;

//   Xodim(this.ism, this.ishTajribasi, this.oylikMaosh);

//   Xodim.yangiXodim(this.ishTajribasi) {
//     double oylik = 1000000;
//     if (ishTajribasi == null) {
//       throw Exception("Xatolik: ish tajribasi xato kiritildi yoki amaliyot vaqtida");
//     } else {
//       oylikMaosh = ishTajribasi! * oylik;
//     }
//   }

//   bonusHisobla() {
//     double bonus = 0;
//     if (oylikMaosh != null) {
//       bonus = oylikMaosh! * 0.1;
//       oylikMaosh = oylikMaosh! + bonus;
//     }
//     return bonus;
//   }

//   void yillikOylikHisobla() {
//     for (int yil = 1; yil <= ishTajribasi!; yil++) {
//       double bonus = bonusHisobla();
//       print("Yil $yil: Oylik maoshi: $oylikMaosh, Qo'shilgan bonus: $bonus");
//     }
//   }

//   String info() {
//     return "Ism: $ism\nIsh tajribasi: $ishTajribasi\nOylik maoshi: $oylikMaosh";
//   }
// }

// void main() {
//   Xodim xodim = Xodim.yangiXodim(5);
//   xodim.ism = "Ali";
  
//   xodim.bonusHisobla();
  
//   print(xodim.info());
//   double bonus = xodim.bonusHisobla();
//   print("Qo'shilgan bous: $bonus");
// }


