// class Kitob{
//   String nom;
//   String muallif;
//   int sahifalarSoni;

//   Kitob(this.nom, this.muallif, this.sahifalarSoni);

//   Kitob.qisqaKitob(this.nom, this.muallif, this.sahifalarSoni){
//     if( sahifalarSoni >= 100){
//       throw Exception ("Sahifalar soni 100 tadan kam bo'lishi kerak");
//     }
//   }

//   kitobMalumotlari(){
//     return "Kitob nomi: $nom\nMuallifi: $muallif\nSahifalar soni: $sahifalarSoni";
//   }
// }

// void main(){
//   var kitob1 = Kitob("Izlash", "Mehmet Olaqosh", 110);
//   print(kitob1.kitobMalumotlari());
// }

// class Xodim {
//   String? ism;
//   double? oylikMaosh;
//   int? ishTajribasi;

//   Xodim(this.ism, this.ishTajribasi, this.oylikMaosh);

//   Xodim.yangiXodim(this.ishTajribasi) {
//     double oylik = 1000000;
//     if (ishTajribasi == null) {
//       throw Exception("Xatolik: ish tajribasi xato kiritildi yoki amaliyot vaqtida");
//     } else {
//       oylikMaosh = ishTajribasi! * oylik;
//     }
//   }

//   double bonusHisobla() {
//     double bonus = 0;
//     if (oylikMaosh != null) {
//       bonus = oylikMaosh! * 0.1;
//       oylikMaosh = oylikMaosh! + bonus;
//     }
//     return bonus;
//   }

//   // void yillikOylikHisobla() {
//   //   for (int yil = 1; yil <= ishTajribasi!; yil++) {
//   //      // Har yili bonus hisoblash
//   //     print("Yil $yil: Oylik maoshi: $oylikMaosh, Qo'shilgan bonus: $bonus");
//   //   }
//   // }

//   String info() {
//     double bonus = bonusHisobla();
//     return "Ism: $ism\nIsh tajribasi: $ishTajribasi\nOylik maoshi: $oylikMaosh\nQo'shilgan bonus: $bonus";
//   }
// }

// void main() {
//   Xodim xodim = Xodim.yangiXodim(5);
//   xodim.ism = "Ali";
//   // xodim.yillikOylikHisobla();

//   print(xodim.info());
// }


// class MaishiyTexnika{
//   String? tur;
//   int? kunlikEnergiyaSarfi;
//   int? ishKunlarSoni;

//   MaishiyTexnika(this.tur, this.ishKunlarSoni, this.kunlikEnergiyaSarfi);

//   MaishiyTexnika.texnika(){
//     tur = "Samsung";
//     kunlikEnergiyaSarfi = 2;
//     ishKunlarSoni = 25;
//   }
//   oylikEnergiyaSarfi(){
//     return (kunlikEnergiyaSarfi! * ishKunlarSoni!);
//   }
//   @override
//   String toString() {
    
//     return "Nomi: $tur\nKunlik sarfi: $kunlikEnergiyaSarfi Kv/Soat\nIsh kunlari: $ishKunlarSoni\nOylik energiya sarfi: ${oylikEnergiyaSarfi()} Kv/Soat";
//   }
// }

// void main(){
//   var mashina1 = MaishiyTexnika("LG", 20, 3);
//   var mashina2 = MaishiyTexnika.texnika();

//   print(mashina1);
//   print(mashina2);
// }




// class Kafedra{
//   String nom;
//   String manzil;
//   int mijozlarSoni;

//   Kafedra(this.nom, this.manzil, this.mijozlarSoni);

//   mijozQosh(){
//     mijozlarSoni += 1;
//   }

//   kafedraMalumotlari(){
//     return "Nomi: $nom\nManzil: $manzil\nMijozlar soni: $mijozlarSoni";
//   }
// }

// void main(){
//   Kafedra kafedra = Kafedra("KLT", "Farg'ona", 20);
//   kafedra.mijozQosh();
//   print(kafedra.kafedraMalumotlari());
// }

class ElektrAvtomobil{
  String? model;
  int? batareyaSigimi;
  int? masofa;

  ElektrAvtomobil(this.model, this.batareyaSigimi, this.masofa);

  ElektrAvtomobil.byd(){
    model = "BYD";
    batareyaSigimi = 60;
    masofa = 5;
  }

  masofaniHisobla(){
    int yuradi = masofa! * batareyaSigimi!;
    return yuradi;

  }
  show(){
    print("Nomi: $model\nBatareya sig'imi: $batareyaSigimi Kv/soat\nTo'liq quvvat bilan ${masofaniHisobla()} masofa yo'l yuradi");
  }
}

void main(){
  ElektrAvtomobil mashina1 = ElektrAvtomobil("Tesla", 70, 5);
  var mashina2 = ElektrAvtomobil.byd();
  mashina1.show();
  mashina2.show();

  
}