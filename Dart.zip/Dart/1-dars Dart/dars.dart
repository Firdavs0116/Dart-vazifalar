

void main() {
  // var x = 9;
  // var y = x<<2;
  // var y2 = x>>1;

  // print("x << 2 = $y");
  // print("x >> 1 = $y2");

  // var a = 25;
  // var b = 10;
  // a |= b;
  // print(a);
  // print(b ^= a);
  // a<<=1;
  // print(a);
  // print(~b);

//   var num = 20;
//   var result = (num > 0) ? print("Musbat") : (num < 0) ? print("Manfiy") : print("Nol");


}
