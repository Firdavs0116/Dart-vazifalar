void main() {

  //  1 -  misol

  // int  a = 5;
  // int b = 3;
  // int sum = a + b;
  // print(sum);

  //  2 - misol

  // int a = 10;
  // int b = 2;
  // int sum = a ~/ b;
  // print(sum);

  //  3 - misol

  // String name = "Firdavs";
  // print(name);

  //  4-misol
  
  // int age = 22;
  // print(age);

  // 5-misol

  // double P = 3.14;
  // int R = 7;
  // var area = P * R * R;
  // print(area);

  // 6-misol

  // int a = 15;
  // int b = 4;
  // int remainder = a % b;
  // print(remainder);

  // 7-misol
  // int pagesPerDay = 25;
  // int book = 200;
  // num kun = book / pagesPerDay;
  // print(kun);

  // 8-misol
  // num income = 2500000;
  // num expences = 2300000;
  // num savings = income - expences;
  // print(savings);

  // 9-misol
  // num F = 98.6;
  // num celcius = (F-32) * 5 / 9;
  // print(celcius);

  // 10-misol
  num distance = 1.2;
  num v = 40;
  num travelTime = distance / v;
  num min = travelTime * 60;
  print("$travelTime shuncha soatda yetib boradi bu esa $min daqiqaga teng ");
}