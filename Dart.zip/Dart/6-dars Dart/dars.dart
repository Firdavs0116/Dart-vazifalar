// void main(){

//   SanoatMahsuloti dena = 
//       SanoatMahsuloti(nom: "Dena", narx: 13000, yil: 2024);
//   SanoatMahsuloti bliss = 
//       SanoatMahsuloti(nom: "Bliss", narx: 13000, yil: 2024);
    
//   print(dena);
//   print(bliss);
// }



// class SanoatMahsuloti {
//   String nom;
//   double narx;
//   int yil;

//   SanoatMahsuloti({
//     required this.nom,
//     required this.narx,
//     required this.yil,
//   });

//   @override
//   String toString() {
    
//     return "Mahsulot nomi: $nom\nMahsulot yili $yil\nMahsulot narxi: $narx";
//   }
// }


