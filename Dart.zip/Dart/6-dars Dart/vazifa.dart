import 'dart:io';

// // 2-misol

// void main(){
//  BadiiyAsar kitb1 = BadiiyAsar(nom: "Dor ostidagi odam", muallif: "Amina Shenliko'g'li", janr: "Badiiy");
//  BadiiyAsar kitb2 = BadiiyAsar(nom: "Oq kema", muallif: "Chingiz Aytmatov", janr: "Badiiy");
//  BadiiyAsar kitb3 = BadiiyAsar(nom: "Ilm olish sirlari", muallif: "Imom Zarnujiy", janr: "Badiiy");
//  kitb1.asarningMalumotlari();
//  kitb2.asarningMalumotlari();
//  kitb3.asarningMalumotlari();

//  List<BadiiyAsar> kitoblar = [kitb1, kitb2, kitb3];

//  for(int i = 0; i < kitoblar.length; i++){
//   print(kitoblar[i].asarningMalumotlari());
//   print("___________________");
//  }
// }

// class BadiiyAsar{
//  String nom;
//  String muallif;
//  String janr;

//  BadiiyAsar({
//   required this.nom,
//   required this.muallif,
//   required this.janr,
//  });

//  String asarningMalumotlari(){
//   return "Kitob nomi: $nom\nMuallif: $muallif\nJanri: $janr";
//  }
// }

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

//3-misol

// void main(){
//  talabalarSoniniTopish();

// }
// talabalarSoniniTopish(){
//   // print("Nechta talaba kiritmoqchisiz: ");
//   stdout.write("Nechta talaba kiritmoqchisiz: ");
//   int? n = int.parse(stdin.readLineSync()!);
//   List<Talaba> talabalar = [];

//   for( int i = 0; i < n; i ++){
//     stdout.write("${i+1} - talabaning ismini kiriting: ");
//     String name = stdin.readLineSync()!;
//     stdout.write("${i+1} - talabaning yoshini kiriting: ");
//     int? age = int.parse(stdin.readLineSync()!);
//     stdout.write("${i+1} - talabaning kursini kiriting: ");
//     int? course = int.parse(stdin.readLineSync()!);

//     Talaba talaba = Talaba(ism: name, yosh: age, kurs: course);
//     talabalar.add(talaba);
//   }

//   for(Talaba talaba in talabalar){
//     print("_____________________________");
//     print(talaba.talabaMalumotlari());
//   }
//   print("_____________________________");
//   print("Jami $n ta talaba mavjud");
// }

// class Talaba{
//   String ism;
//   int yosh;
//   int kurs;

//   Talaba({
//     required this.ism,
//     required this.yosh,
//     required this.kurs,
//   });
//   talabaMalumotlari(){
//     return "Ism: $ism\nYosh: $yosh\nKurs: $kurs";
//   }

// }

//  4-misol

// class Taom {
//   String nom;
//   double narx;
//   double kaloriya;

//   Taom({
//     required this.nom,
//     required this.narx,
//     required this.kaloriya,
//   });

//   String taomMalumotlari() {
//     return "Nomi: $nom\nNarxi: $narx\nKaloriyasi: $kaloriya";
//   }
// }

// class Restoran {
//   List<Taom> taomlar;

//   Restoran({
//     required this.taomlar,
//   });

//   void taomQosh(Taom taom) {
//     taomlar.add(taom);
//   }

//   String restoranTaomlari() {
//     if (taomlar.isEmpty) {
//       return "Restoranda taomlar mavjud emas.";
//     }
    
//     String natija = "Restorandagi taomlar:\n";
//     for (Taom taom in taomlar) {
//       natija += "${taom.taomMalumotlari()}\n";
//       natija += "-------------------------\n";
//     }
//     return natija;
//   }
// }

// void taomlarSoniniTopish() {
//   stdout.write("Nechta taom kiritmoqchisiz: ");
//   int n = int.parse(stdin.readLineSync()!);
//   Restoran restoran = Restoran(taomlar: []);

//   for (int i = 0; i < n; i++) {
//     stdout.write("${i + 1} - taom nomini kiriting: ");
//     String nom = stdin.readLineSync()!;
//     stdout.write("${i + 1} - taom narxini kiriting: ");
//     double narx = double.parse(stdin.readLineSync()!);
//     stdout.write("${i + 1} - taom kaloriyasini kiriting: ");
//     double kaloriya = double.parse(stdin.readLineSync()!);

//     Taom taom = Taom(nom: nom, narx: narx, kaloriya: kaloriya);
//     restoran.taomQosh(taom);
//   }

//   print("\n${restoran.restoranTaomlari()}");
// }

// void main() {
//   taomlarSoniniTopish();
// }



// 5-misol

class Futbolchi{
  String ism;
  String pozitsiya;
  int gollarSon;

  Futbolchi({
    required this.ism,
    required this.pozitsiya,
    required this.gollarSon
  });
  malumotlar(){
    return "Ism: $ism\nPozitsiya: $pozitsiya\nGo'llar soni: $gollarSon";
  }
}
class Jamoa{

  List<Futbolchi> player = [];
  futbolchiQosh(Futbolchi futbolchi){
    player.add(futbolchi);
  }

  //: engYuqoriGollar() metodini chaqirganda quyidagi ko'rinishda ma'lumotlar
  // chop etilsin: "Eng ko'p gol urgan futbolchi: [ism] - [gollarSon] gollar."
  engYuqoriGollar(){
    if (player.isEmpty) 
    {
      print("Jamoada futbolchilar yo'q.");
      return;
    }
    else
    {
      Futbolchi engYuqori = player[0];
      for (var futbolchi in player) {
        if (futbolchi.gollarSon > engYuqori.gollarSon) {
         engYuqori = futbolchi;
        }
      }
      print("Eng ko'p gol urgan futbolchi: ${engYuqori.ism} - ${engYuqori.gollarSon} gollar.");
    }
  }
}


void main(){

  Jamoa jamoa = Jamoa();

  jamoa.futbolchiQosh(Futbolchi(ism: "Ali", pozitsiya: "Hujumchi", gollarSon: 10));
  jamoa.futbolchiQosh(Futbolchi(ism: "Vali", pozitsiya: "Hujumchi", gollarSon: 15));
  jamoa.futbolchiQosh(Futbolchi(ism: "Olim", pozitsiya: "Yarim himoyachi", gollarSon: 5));
  jamoa.futbolchiQosh(Futbolchi(ism: "Bobur", pozitsiya: "Himoyachi", gollarSon: 7));

  jamoa.engYuqoriGollar();
}