import 'dart:io';

void main() {

  // 1- misol

  //  // Tashqi tsikl
  // for (var i = 0; i < 3; i++) {
  //   print("Tashqi tsikl: $i");

  //   // Ichki tsikl
  //   for (var j = 0; j < 2; j++) {
  //     print("  Ichki tsikl: $j");
  //   }
  // }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>

  // 2-misol

  // print("Sonlarni ( , ) bilan ajratib kiriting!!!");
  // String ? matn = stdin.readLineSync();

  // if(matn != null && matn.isNotEmpty){
  //   List<int>sonlar = matn.split(',')
  //   .map((e) => int.tryParse(e.trim()))
  //   .where((e) => e != null)
  //   .cast<int>()
  //   .toList();
  //   print(sonlar);
  // }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  // 3-misol

  // print("Son kiriting.");

  // int ? son = int.parse(stdin.readLineSync()!);
  // for( var i = 0; i < son; i++){
  //   for(var l = 0; l < son; l++){
  //     stdout.write("($i, $l)");
  //   }
  //   print("");
  // }


  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  // 4-misol
  // print("Nechta son kiritmoqchisiz.");
  // int ? n = int.parse(stdin.readLineSync()!);
  // int c = 10;
  // for( int i = 0; i <= n ~/ c; i++){
  //   for(int l = 0; l < c; l++ ){
  //     int son = i * c + l;
  //     if (son <= n){
  //       stdout.write("$son, ");
        
  //     }
  //   }
  //   print('');
  // }

  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

  //5.1-misol

  // print("Son kiriting.");

  // int ? son = int.parse(stdin.readLineSync()!);

  // for( int i = son; i > 0; i--){
  //   for( int l = 0; l < i; l++ ){
  //     stdout.write(" *");
  //   }
  //   print('');
  // }

  // 2-usul

  // print("Son kiriting.");

  // int ? son = int.parse(stdin.readLineSync()!);
  // for(int i = son; i > 0; i--){
  //   String a = ' *' * i;
  //   print(a);
  // }

  //5.2-misol

  print("Necha qator bo'lishini kiriting.");

  int ? son = int.parse(stdin.readLineSync()!);
  for( int i = 0; i < son; i++){
    String a = ' ' * i;
    String c = ' *' * 4;
    print('$a$c');
  }

  // 5.3 - misol

  // print("Necha qator bo'lishini kiriting.");

  // int ? son = int.parse(stdin.readLineSync()!);

  // for( int i = 0; i < son-1; i++){

  //   if( i == 0){
  //     String a = "*" * son;
  //     print(a);
  //   }
  //   else{
  //     String bosh = ' ' * (son-2);
  //     print("*${bosh}*");
  //   }
  // }
  // String a = "*" * son;
  // print(a);


  // 5.4 - misol

  // print("Necha qator bo'lishini kiriting.");

  // int ? son = int.parse(stdin.readLineSync()!);
  // int a = son - 1;
  // for(int i = 0; i < son; i ++){
  //   String c = "*";
  //   String plus = " +" * a;
  //   String minus = " -" * i;
  //   a -= 1;
  //   print("${minus} ${c} ${plus}");
  // }


// 5.5 - misol
  // print("Necha qator bo'lishini kiriting.");

  // int ? son = int.parse(stdin.readLineSync()!);
  // int a = son - 2;
  // for( int i = 0; i < son ~/ 2; i ++){
  //   String bosh = ' ' * i;
  //   String empty = ' ' * (a - i);
  //   print("$bosh*${empty}$empty*");
  // }
  // for( int i = son ~/ 2; i >= 0; i --){
  //   String bosh = ' ' * i;
  //   String empty = ' ' * (a - i);
  //   print("$bosh*${empty}$empty*");
  // }
}
