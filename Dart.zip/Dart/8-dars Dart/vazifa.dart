// class Smartfon{
//   String _nomi = "";
//   String _brend = ""; 
//   double _narx = 0;


//   String get getNomi => _nomi;
//   String get getBrend => _brend;
//   double get ggetNarx => _narx;

//   set setNomi(String newNomi) => _nomi = newNomi;
//   set setBrend(String newBrend) => _brend = newBrend;
//   set setNarx(double newNarx){
//     if (newNarx > 0){
//       _narx = newNarx;
//     }
//   }
// }

// void main(){
//   Smartfon phone = Smartfon();
//   // print(phone._brend);
//   phone.setNomi = "Iphone 11";
//   phone.setBrend = "Apple";
//   phone.setNarx = 350;
//   print("Nomi: ${phone.getNomi} Brendi: ${ phone.getBrend}  Narxi: ${phone.ggetNarx}");
// }


// class Kitob{
//   String nomi;
//   String muallif;
//   int _sahifalarSoni;
//   static int umumiyKitoblarSoni = 0;

//   Kitob(this.nomi, this.muallif,  this._sahifalarSoni){
//     umumiyKitoblarSoni++;
//   }
  
//   int get getSahifaSoni => _sahifalarSoni;

  
//   set setSahifalarSoni(int newSahifaSoni){
//     if (newSahifaSoni > 0){
//        _sahifalarSoni = newSahifaSoni;
//     }
//     else{
//       throw Exception("Sahifalar soni 0 dan ko'p bo'lishi kerak");
//     }
//   }
// }

// void main(){
//   Kitob kitob1 = Kitob("Izlash", "Mehmet Olaqosh", 240);
//   Kitob kitob2 = Kitob("Qo'rqma", "Javlon Joliyev", 500);
//   Kitob kitob3 = Kitob("Qutadg'u bilig", "Alisher Navoiy", 300);

//   print("Umumiy kitobllar soni: ${Kitob.umumiyKitoblarSoni}");
//   print("${kitob1.nomi}, ${kitob1.muallif}, ${kitob1.getSahifaSoni}");
//   print("${kitob2.nomi}, ${kitob2.muallif}, ${kitob2.getSahifaSoni}");
//   print("${kitob3.nomi}, ${kitob3.muallif}, ${kitob3.getSahifaSoni}");
// }

// class BankHisobi{
//   String ism;
//   double _balans;
//   String _valyuta;

//   static int umumiyBankHisob = 0;

//   BankHisobi(this.ism, this._balans, this._valyuta){
//     if(_balans >=5000){
//       umumiyBankHisob++;
//     }
//     else{
//       throw Exception("Bank hisob ochish uchun minimal summa 5000 ");
//     }
//   }

//   double get getBalans => _balans;
//   String get getValyuta => _valyuta;

//   set setBalans(double newBalans){
//     if(newBalans >= 10){
//       _balans = newBalans;

//     }
//     else{
//       throw Exception("Kiritish mumkin bo'lgan minimal summa 5000");
//     }
//   }
//   set setValyuta(String newValyuta) => _valyuta = newValyuta;

//   pulYechish(double miqdor){
//     if( miqdor > 0 && _balans - miqdor >= 10){
//       _balans -= miqdor;
//       print("Pul muvaffaqqtiyatli yechildi");
//     }
//     else{
//       throw Exception("Pul yechish uchun hisobingizda mablag' yetarli emas!!!");
//     }
//   }

//   pulQoshish(double miqdor){
//     if(miqdor > 0){
//       _balans += miqdor;
//       print("Hisobingiz muvaffaqqiyatli to'ldirildi");
//     }
//     else{
//       throw Exception("Hisobingizga pul qo'shmadingiz");
//     }
//   }

//   info(){
//     print("Mijoz: $ism\nBalans: $getBalans\nValyuta: $getValyuta");
//   }
// }

// void main(){
//   BankHisobi hisob1 = BankHisobi("Shahzod", 6500, "UZS");
//   BankHisobi hisob2 = BankHisobi("Begzod", 6000, "USD");
//   BankHisobi hisob3 = BankHisobi("Shaina", 5000, "RUB");
//   BankHisobi hisob4 = BankHisobi("Aziz", 9500, "UZS");

//   hisob1.info();
//   hisob2.info();
//   hisob3.info();
//   hisob4.info();
//   print("__________________________");
//   hisob1.pulQoshish(210);
//   hisob1.info();
//   print("__________________________");
//   hisob4.pulYechish(2000);
//   hisob4.info(); 
// }


// class ToyPlani{
//   int mehmonlarSoni;
//   double budjet;
//   String _joylashuv = "";
//   static int umumiyToy = 0;

//   ToyPlani(this.mehmonlarSoni, this.budjet){
//     if( mehmonlarSoni >= 500 && budjet >= 50000000 ){
//       umumiyToy++;
//     }
//     else if( mehmonlarSoni <= 500 && mehmonlarSoni >= 30){
//       umumiyToy++;
//     }
//     else{
//       throw Exception("To'yga kam mablag' ajratgasiz");
//     }

//   }
//     String get getJoylashuv => _joylashuv;

//     set setJoylashuv(String newJoylashuv) => _joylashuv = newJoylashuv;

//     info(){
//       print("Manzil: $getJoylashuv\nMehmonlar soni: $mehmonlarSoni\nAjratilgan budjet: $budjet so'm");
//     }
// }

// void main(){
//   ToyPlani toy1 = ToyPlani(650, 52000000);
//   toy1.setJoylashuv = "Qayerdagidir To'yxona";
//   toy1.info();
// }


class TolovTizimi{
  static TolovTizimi _tizim = TolovTizimi.
}