import 'vazifa.dart';

void main(){
  Smartfon phone = Smartfon("Samsung note 20", "Samsung", 250);
  print(phone.getBrend);
  Smartfon phone2 = Smartfon("Samsung note 20", "Samsung", 250);
  phone2.setNarx = 200;
  print(phone2.ggetNarx);
  phone.setBrend = "Redmi";
  print(phone.getBrend);

}