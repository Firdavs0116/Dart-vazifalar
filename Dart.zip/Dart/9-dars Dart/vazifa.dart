// void main(){
//   int? raqam;
//   print(raqam ?? "Telefon mavjud emas");
// }

// void main(){
//   // double? discountPercentage;
//   print(chegirma(20));
// }

// double chegirma(double? discountPercentage){
//   return discountPercentage ?? 5;
// }

// class Employee{
//   String name;
//   String? department;
//   int? number;

//   Employee({required this.name});

//   getDetails(){
//     return "Ism: $name\nTelefon: ${number ?? "Aloqa raqami mavjud emas"}\nDepartment: ${department ?? "Bo‘lim belgilanmagan"}";
//   }
// }

// void main(){
//   Employee worker = Employee(name: "Sharif");
//   print(worker.getDetails());
// }

// class Order{
//   int orderID;
//   String productName;
//   int? quantity;
//   int? discount;
//   double? productPrice;
//   // double? totalPrice = 0;

//   Order({required this.orderID, required this.productName});

//   double get totalPrice {
//     if( quantity == null || productPrice == null){
//       return 0;
//     }
//     return quantity! * productPrice!; 
//   }

//   applyDiscount(){
//     double total = totalPrice;
//     if( discount != null){
//       total -= discount!.toDouble();
//     }
//     return total;
//   }
// }

// void main(){
//   Order order = Order(orderID: 1, productName: "Olma");
//   order.quantity = 2;
//   order.productPrice = 12000;
//   order.discount = 10;
//   print("Total price: ${order.totalPrice}");
//   print('Total Price after Discount: ${order.applyDiscount()}');
// }

class Car{
  String model;
  String ownerName;
  int? year;
  int mileage;
  int warranty;

  Car({required this.model, required this.ownerName, required this.warranty, required this.mileage});

  calculateWarranty(){
    int check = mileage ~/ 100000;
    if(warranty - check > 0){
      warranty -= check;
      return warranty;
    }
    else{

      // return "your warranty has expired";
      return warranty = 0;
    }
  }
  getCarDetails(){
    year = year ?? 2000;
    // calculateWarranty();
    return "Model: $model\nOwner: $ownerName\nYear: $year\nMileage: $mileage\nWarranty: ${calculateWarranty() == 0 ? "your warranty has expired" : calculateWarranty()}";
   }

}

void main(){
  Car car1 = Car(model: "Dodge chellenger", ownerName: "Shephard", warranty: 5, mileage: 600000);
  print(car1.getCarDetails());
}