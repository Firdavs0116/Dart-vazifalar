// // import 'dart:math';

// class UserProfile{
//   String? name;
//   String? email;
//   int? age;

//   UserProfile({required this.name, this.age, this.email});

//   String? getProfileInfo(){

//     return "Ism: $name\nYosh: ${age ?? "Yosh kiritilmagan"}\nEmail: ${email ?? "Email kiritilmagan"}";
//   }
  
// }
// void main(){
//   UserProfile user = UserProfile(name: "Shahzod");
//   print(user.getProfileInfo());
// }

class Product{
  String nomi;
  double? narx;
  String? ishlabChiqaruvchiNomi;

  Product({required this.nomi, this.narx, this.ishlabChiqaruvchiNomi});

  displayInfo(){
    return "Ism: $nomi\nNarx: ${narx ?? "Narx kiritilmagan"}\n${ishlabChiqaruvchiNomi ?? "Ishlab chiqaruvchi nomi berilmagan"}";
  }
}

void main(){

  Product user = Product(nomi: "Olma", narx: 6000);
  print(user.displayInfo());
}