class Car{
  String? nomi;
  String? modeli;
  int? year;

  Car({ required this.nomi, required this.modeli, required this.year});
}

void main(){
  Car? nullableCar;

  Car nonNullable = Car(nomi: "Camaro", modeli: "Chevrolet", year: 2020);

  print(nullableCar?.modeli);
  print(nonNullable.modeli);
}