class ShoppingCart{
  List<String>? items;

  void addItems(String item){
    items ??= [];
    items!.add(item);

    items?.forEach((item) => print(item));
  }
}

void main() {
  ShoppingCart cart1 = ShoppingCart();
  cart1.addItems("Salom");
  cart1.addItems("Salom");
  cart1.addItems("Salom");
  // print(cart1);
}
